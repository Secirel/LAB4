--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.0
-- Dumped by pg_dump version 13.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Yevdokimov";
--
-- Name: Yevdokimov; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Yevdokimov" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Kazakh_Kazakhstan.utf8';


ALTER DATABASE "Yevdokimov" OWNER TO postgres;

\connect "Yevdokimov"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: arms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.arms (
    id integer NOT NULL,
    type character varying(100) NOT NULL,
    pistols_id integer NOT NULL,
    rifles_id integer NOT NULL,
    shop_id integer NOT NULL
);


ALTER TABLE public.arms OWNER TO postgres;

--
-- Name: arms_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.arms_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.arms_id_seq OWNER TO postgres;

--
-- Name: arms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.arms_id_seq OWNED BY public.arms.id;


--
-- Name: pistols; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pistols (
    p_id integer NOT NULL,
    p_name character varying(100) NOT NULL,
    p_ammo integer,
    velocity numeric,
    p_caliber_size numeric
);


ALTER TABLE public.pistols OWNER TO postgres;

--
-- Name: pistols_p_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pistols_p_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pistols_p_id_seq OWNER TO postgres;

--
-- Name: pistols_p_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pistols_p_id_seq OWNED BY public.pistols.p_id;


--
-- Name: rifles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rifles (
    r_id integer NOT NULL,
    r_name character varying(100) NOT NULL,
    r_ammo integer,
    shot_range numeric,
    r_caliber_size numeric
);


ALTER TABLE public.rifles OWNER TO postgres;

--
-- Name: rifles_r_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.rifles_r_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rifles_r_id_seq OWNER TO postgres;

--
-- Name: rifles_r_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.rifles_r_id_seq OWNED BY public.rifles.r_id;


--
-- Name: shop_gun; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shop_gun (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    location character varying(100) NOT NULL,
    type_of_shop character varying(100) NOT NULL
);


ALTER TABLE public.shop_gun OWNER TO postgres;

--
-- Name: arms id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.arms ALTER COLUMN id SET DEFAULT nextval('public.arms_id_seq'::regclass);


--
-- Name: pistols p_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pistols ALTER COLUMN p_id SET DEFAULT nextval('public.pistols_p_id_seq'::regclass);


--
-- Name: rifles r_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rifles ALTER COLUMN r_id SET DEFAULT nextval('public.rifles_r_id_seq'::regclass);


--
-- Data for Name: arms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.arms (id, type, pistols_id, rifles_id, shop_id) FROM stdin;
\.
COPY public.arms (id, type, pistols_id, rifles_id, shop_id) FROM '$$PATH$$/3018.dat';

--
-- Data for Name: pistols; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pistols (p_id, p_name, p_ammo, velocity, p_caliber_size) FROM stdin;
\.
COPY public.pistols (p_id, p_name, p_ammo, velocity, p_caliber_size) FROM '$$PATH$$/3013.dat';

--
-- Data for Name: rifles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rifles (r_id, r_name, r_ammo, shot_range, r_caliber_size) FROM stdin;
\.
COPY public.rifles (r_id, r_name, r_ammo, shot_range, r_caliber_size) FROM '$$PATH$$/3015.dat';

--
-- Data for Name: shop_gun; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shop_gun (id, name, location, type_of_shop) FROM stdin;
\.
COPY public.shop_gun (id, name, location, type_of_shop) FROM '$$PATH$$/3016.dat';

--
-- Name: arms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.arms_id_seq', 1, false);


--
-- Name: pistols_p_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pistols_p_id_seq', 1, false);


--
-- Name: rifles_r_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rifles_r_id_seq', 1, false);


--
-- Name: arms arms_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.arms
    ADD CONSTRAINT arms_pkey PRIMARY KEY (id);


--
-- Name: pistols pistols_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pistols
    ADD CONSTRAINT pistols_pkey PRIMARY KEY (p_id);


--
-- Name: rifles rifles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rifles
    ADD CONSTRAINT rifles_pkey PRIMARY KEY (r_id);


--
-- Name: shop_gun shop_gun_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shop_gun
    ADD CONSTRAINT shop_gun_pkey PRIMARY KEY (id);


--
-- Name: arms fk_pistols; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.arms
    ADD CONSTRAINT fk_pistols FOREIGN KEY (pistols_id) REFERENCES public.pistols(p_id);


--
-- Name: arms fk_rifles; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.arms
    ADD CONSTRAINT fk_rifles FOREIGN KEY (rifles_id) REFERENCES public.rifles(r_id);


--
-- Name: arms fk_shop; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.arms
    ADD CONSTRAINT fk_shop FOREIGN KEY (shop_id) REFERENCES public.shop_gun(id);


--
-- PostgreSQL database dump complete
--

